# Description

This Jupyter Notebook allows you to quickly query a public Steam XML for a given user and create some visualizations about their Steam game library.

# Dependencies

- Bokeh
- Numpy
- Pandas
- Requests